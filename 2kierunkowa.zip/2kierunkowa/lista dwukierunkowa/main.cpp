
#include <iostream>
#include <cstdlib>  // Biblioteka do losowania liczb
#include <ctime>    // Biblioteka do mierzenia czasu
using namespace std;


// STRUKTURA LISTY DWUKIERUNKOWEJ
struct lista2 {

    int liczba;          // Przechowuje liczbe

    lista2 *next;        // Wskaznik na nastepny element

    lista2 *prev;        // Wskaznik na poprzedni element
};


// FUNKCJA DODAJACA ELEMENT NA KONIEC LISTY
void dodaj(lista2*& pierwszy, lista2*& ostatni, int liczba) {

    lista2* nowy = new lista2; // Tworzymy nowy element listy

    nowy->liczba = liczba;     // Zapisujemy liczbe w elemencie

    nowy->next = NULL;         // Nowy element nie ma nastepnego elementu

    nowy->prev = ostatni;      // Poprzednim elementem jest dotychczasowy koniec

    // Sprawdzamy, czy lista jest pusta
    if (pierwszy == NULL) {

        pierwszy = nowy;       // Nowy element jest pierwszym elementem

        ostatni = nowy;        // Nowy element jest rowniez ostatnim elementem
    }
    else {

        ostatni->next = nowy;  // Poprzedni koniec wskazuje na nowy element

        ostatni = nowy;        // Ustawiamy nowy koniec listy
    }
}


// FUNKCJA SZUKAJACA NAJWIEKSZEGO ELEMENTU W LISCIE
lista2* znajdzMax(lista2* pierwszy) {

    lista2* max = pierwszy;    // Zakladamy, ze pierwszy element jest najwiekszy

    // Przechodzimy przez wszystkie elementy listy
    while (pierwszy != NULL) {

        // Sprawdzamy, czy aktualna liczba jest wieksza od maksimum
        if (pierwszy->liczba > max->liczba) {

            max = pierwszy;    // Zapamietujemy wskaznik na najwiekszy element
        }

        pierwszy = pierwszy->next; // Przechodzimy do nastepnego elementu
    }

    return max; // Zwracamy wskaznik na najwiekszy element
}


// FUNKCJA ZAMIENIAJACA LICZBY MIEJSCAMI
void zamien(lista2* a, lista2* b) {

    int pom = a->liczba;        // Zapamietujemy pierwsza liczbe

    a->liczba = b->liczba;      // Wpisujemy druga liczbe w miejsce pierwszej

    b->liczba = pom;            // Wpisujemy zapamietana liczbe w drugie miejsce
}


// SORTOWANIE LISTY DWUKIERUNKOWEJ MALEJACO
void sortujListe(lista2* pierwszy) {

    lista2* aktualny = pierwszy; // Ustawiamy wskaznik na poczatek listy

    // Przechodzimy po kolejnych elementach listy
    while (aktualny != NULL) {

        // Szukamy najwiekszej liczby od aktualnego elementu do konca
        lista2* max = znajdzMax(aktualny);

        // Sprawdzamy, czy maksimum znajduje sie na innym miejscu
        if (max != aktualny) {

            zamien(aktualny, max); // Zamieniamy liczby miejscami
        }

        aktualny = aktualny->next; // Przechodzimy do kolejnego elementu
    }
}


// FUNKCJA SZUKAJACA NAJWIEKSZEJ LICZBY W TABLICY
int znajdzMaxTab(int tab[], int start, int n) {

    int max = start; // Zakladamy, ze pierwszy sprawdzany element jest najwiekszy

    // Przechodzimy przez pozostala czesc tablicy
    for (int i = start + 1; i < n; i++) {

        // Sprawdzamy, czy znalezlismy wieksza liczbe
        if (tab[i] > tab[max]) {

            max = i; // Zapamietujemy indeks najwiekszej liczby
        }
    }

    return max; // Zwracamy indeks najwiekszej liczby
}


// SORTOWANIE TABLICY MALEJACO
void sortujTablice(int tab[], int n) {

    // Przechodzimy przez wszystkie elementy tablicy
    for (int i = 0; i < n; i++) {

        int max = znajdzMaxTab(tab, i, n); // Szukamy najwiekszej liczby

        int pom = tab[i];       // Zapamietujemy aktualna liczbe

        tab[i] = tab[max];      // Wstawiamy maksimum na aktualne miejsce

        tab[max] = pom;         // Przenosimy zapamietana liczbe na miejsce maksimum
    }
}


// FUNKCJA WYSWIETLAJACA POCZATKOWE LICZBY Z LISTY
void pokazPoczatek(lista2* pierwszy, int ile) {

    int i = 0; // Licznik wypisanych elementow

    // Wypisujemy okreslona liczbe elementow
    while (pierwszy != NULL && i < ile) {

        cout << pierwszy->liczba << " "; // Wypisujemy liczbe

        pierwszy = pierwszy->next;      // Przechodzimy do nastepnego elementu

        i++; // Zwiekszamy licznik
    }

    cout << endl;
}


// FUNKCJA ZWALNIAJACA PAMIEC LISTY
void zwolnij(lista2*& pierwszy) {

    // Przechodzimy przez wszystkie elementy listy
    while (pierwszy != NULL) {

        lista2* pom = pierwszy; // Zapamietujemy aktualny element

        pierwszy = pierwszy->next; // Przechodzimy do nastepnego elementu

        delete pom; // Usuwamy poprzedni element z pamieci
    }
}


// GLOWNA FUNKCJA PROGRAMU
int main() {

    const int N = 50000; // Ustalamy liczbe generowanych elementow

    int* tab = new int[N]; // Tworzymy dynamiczna tablice na 50000 liczb

    lista2* pierwszy = NULL; // Wskaznik na pierwszy element listy

    lista2* ostatni = NULL; // Wskaznik na ostatni element listy

    srand(time(NULL)); // Inicjujemy generator liczb losowych


    // GENEROWANIE LICZB
    // Te same liczby zapisujemy do tablicy i listy
    for (int i = 0; i < N; i++) {

        int liczba = rand() % 100000; // Losujemy liczbe od 0 do 99999

        tab[i] = liczba; // Zapisujemy liczbe do tablicy

        dodaj(pierwszy, ostatni, liczba); // Dodajemy liczbe do listy
    }

    cout << "Wygenerowano " << N << " liczb." << endl;


    // WYSWIETLANIE POCZATKOWYCH LICZB
    cout << endl;

    cout << "Poczatkowe 20 liczb z listy:" << endl;

    pokazPoczatek(pierwszy, 20);


    // SORTOWANIE TABLICY I POMIAR CZASU
    clock_t start = clock(); // Zapamietujemy czas rozpoczecia

    sortujTablice(tab, N); // Sortujemy tablice malejaco

    clock_t koniec = clock(); // Zapamietujemy czas zakonczenia

    // Obliczamy czas sortowania tablicy w sekundach
    double czasTablicy =
        double(koniec - start) / CLOCKS_PER_SEC;


    // SORTOWANIE LISTY I POMIAR CZASU
    start = clock(); // Zapamietujemy czas rozpoczecia

    sortujListe(pierwszy); // Szukamy maksimum i zamieniamy z aktualnym elementem

    koniec = clock(); // Zapamietujemy czas zakonczenia

    // Obliczamy czas sortowania listy w sekundach
    double czasListy =
        double(koniec - start) / CLOCKS_PER_SEC;


    // WYSWIETLANIE POSORTOWANYCH LICZB
    cout << endl;

    cout << "Posortowane 20 liczb z listy:" << endl;

    pokazPoczatek(pierwszy, 20);


    // WYSWIETLANIE CZASOW SORTOWANIA
    cout << endl;

    cout << "CZAS SORTOWANIA:" << endl;

    cout << "Tablica: " << czasTablicy << " sekund" << endl;

    cout << "Lista dwukierunkowa: " << czasListy << " sekund" << endl;


    // ZWALNIANIE PAMIECI
    zwolnij(pierwszy); // Usuwamy wszystkie elementy listy

    delete[] tab; // Usuwamy dynamiczna tablice

    return 0; // Konczymy program
}
