
#include <iostream>
#include <vector>
#include <list>
#include <algorithm>
#include <chrono>
#include <cstdlib>

using namespace std;

int main()
{
    const int N = 100000;

    // Tablica przechowujaca 100000 losowych liczb
    int liczby[N];

    // Losowanie liczb
    for (int i = 0; i < N; i++)
    {
        liczby[i] = rand();
    }

    // Zmienne do mierzenia czasu
    chrono::steady_clock::time_point start, koniec;

    // =====================================
    // VECTOR
    // =====================================

    cout << "===== VECTOR =====" << endl;

    vector<int> v;

    // Dodawanie liczb do vectora
    start = chrono::steady_clock::now();

    for (int i = 0; i < N; i++)
    {
        v.push_back(liczby[i]);
    }

    koniec = chrono::steady_clock::now();

    cout << "Dodawanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Sortowanie vectora
    start = chrono::steady_clock::now();

    sort(v.begin(), v.end());

    koniec = chrono::steady_clock::now();

    cout << "Sortowanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Usuwanie elementu ze srodka
    start = chrono::steady_clock::now();

    v.erase(v.begin() + N / 2);

    koniec = chrono::steady_clock::now();

    cout << "Usuwanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Wstawianie elementu na srodek
    start = chrono::steady_clock::now();

    v.insert(v.begin() + N / 2, 123);

    koniec = chrono::steady_clock::now();

    cout << "Wstawianie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;


    // =====================================
    // TABLICA
    // =====================================

    cout << endl << "===== TABLICA =====" << endl;

    // N+1, zeby bylo miejsce na dodatkowy element
    int tablica[N + 1];

    // Kopiowanie liczb do tablicy
    start = chrono::steady_clock::now();

    for (int i = 0; i < N; i++)
    {
        tablica[i] = liczby[i];
    }

    koniec = chrono::steady_clock::now();

    cout << "Dodawanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Sortowanie tablicy
    start = chrono::steady_clock::now();

    sort(tablica, tablica + N);

    koniec = chrono::steady_clock::now();

    cout << "Sortowanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Usuwanie elementu ze srodka
    start = chrono::steady_clock::now();

    for (int i = N / 2; i < N - 1; i++)
    {
        tablica[i] = tablica[i + 1];
    }

    koniec = chrono::steady_clock::now();

    cout << "Usuwanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Wstawianie elementu na srodek
    start = chrono::steady_clock::now();

    for (int i = N - 1; i >= N / 2; i--)
    {
        tablica[i + 1] = tablica[i];
    }

    tablica[N / 2] = 123;

    koniec = chrono::steady_clock::now();

    cout << "Wstawianie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;


    // =====================================
    // LISTA
    // =====================================

    cout << endl << "===== LISTA =====" << endl;

    list<int> lista;

    // Dodawanie liczb do listy
    start = chrono::steady_clock::now();

    for (int i = 0; i < N; i++)
    {
        lista.push_back(liczby[i]);
    }

    koniec = chrono::steady_clock::now();

    cout << "Dodawanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Sortowanie listy
    start = chrono::steady_clock::now();

    lista.sort();

    koniec = chrono::steady_clock::now();

    cout << "Sortowanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Usuwanie elementu ze srodka
    start = chrono::steady_clock::now();

    auto it = lista.begin();

    advance(it, N / 2);

    lista.erase(it);

    koniec = chrono::steady_clock::now();

    cout << "Usuwanie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    // Wstawianie elementu na srodek
    start = chrono::steady_clock::now();

    auto it2 = lista.begin();

    advance(it2, N / 2);

    lista.insert(it2, 123);

    koniec = chrono::steady_clock::now();

    cout << "Wstawianie: "
         << chrono::duration_cast<chrono::microseconds>(koniec - start).count()
         << " mikrosekund" << endl;

    return 0;
}
