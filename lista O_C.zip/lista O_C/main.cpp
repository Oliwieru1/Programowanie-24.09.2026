
#include <iostream>
#include <fstream>
using namespace std;

// Jeden element listy
struct lista {
    int id;          // Przechowywana liczba
    lista *next;     // Wskaznik na nastepny element
};

// Wczytywanie liczb z pliku
void wczytaj(lista *&L, lista *&P) {

    ifstream plik("liczby.txt"); // Otwieramy plik
    int liczba;

    // Sprawdzamy, czy plik sie otworzyl
    if (!plik) {
        cout << "Nie mozna otworzyc pliku!";
        return;
    }

    // Wczytujemy liczby z pliku
    while (plik >> liczba) {

        // Tworzymy nowy element listy
        lista *nowy = new lista;

        nowy->id = liczba;  // Zapisujemy liczbe
        nowy->next = NULL;  // Brak nastepnego elementu

        // Jesli lista jest pusta
        if (L == NULL) {
            L = nowy;       // Pierwszy element
            P = nowy;       // Ostatni element
        }
        else {
            P->next = nowy; // Dolaczamy na koncu
            P = nowy;       // Zmieniamy koniec listy
        }
    }

    plik.close(); // Zamykamy plik
}

// Wypisywanie listy
void wypisz(lista *L) {

    // Przechodzimy przez wszystkie elementy
    while (L != NULL) {

        cout << L->id << " "; // Wypisujemy liczbe

        L = L->next; // Przechodzimy dalej
    }

    cout << endl;
}

// Usuwanie calej listy z pamieci
void zwolnij(lista *&L) {

    while (L != NULL) {

        lista *pom = L; // Zapamietujemy element

        L = L->next;    // Przechodzimy do nastepnego

        delete pom;     // Usuwamy poprzedni element
    }
}

int main() {

    lista *L = NULL; // Poczatek listy
    lista *P = NULL; // Koniec listy

    wczytaj(L, P); // Wczytujemy liczby

    cout << "Liczby w liscie: ";

    wypisz(L); // Wypisujemy liczby

    zwolnij(L); // Zwalniamy pamiec

    return 0;
}
