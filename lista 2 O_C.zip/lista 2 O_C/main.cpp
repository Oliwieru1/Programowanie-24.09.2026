
#include <iostream>
#include <fstream>
using namespace std;

// Jeden element listy
struct Element {
    int liczba;       // Przechowuje liczbe
    Element* next;    // Wskazuje na nastepny element
};

// Wczytywanie liczb z pliku
void wczytaj(Element*& glowa) {

    ifstream plik("liczby.txt"); // Otwieramy plik
    int liczba;

    Element* koniec = NULL; // Ostatni element listy

    // Sprawdzamy, czy plik sie otworzyl
    if (!plik) {
        cout << "Nie mozna otworzyc pliku!\n";
        return;
    }

    // Wczytujemy liczby z pliku
    while (plik >> liczba) {

        // Tworzymy nowy element
        Element* nowy = new Element;

        nowy->liczba = liczba; // Zapisujemy liczbe
        nowy->next = NULL;     // Brak nastepnego elementu

        // Jezeli lista jest pusta
        if (glowa == NULL) {
            glowa = nowy;
            koniec = nowy;
        }
        else {
            koniec->next = nowy; // Dodajemy na koncu
            koniec = nowy;       // Zmieniamy koniec listy
        }
    }

    plik.close(); // Zamykamy plik
}

// Wyswietlanie listy
void wyswietl(Element* glowa) {

    // Przechodzimy przez cala liste
    while (glowa != NULL) {

        cout << glowa->liczba << " ";

        glowa = glowa->next; // Przechodzimy dalej
    }

    cout << endl;
}

// Wyszukiwanie liczby
void szukaj(Element* glowa, int liczba) {

    // Sprawdzamy kolejne elementy
    while (glowa != NULL) {

        if (glowa->liczba == liczba) {
            cout << "Jest taka liczba\n";
            return;
        }

        glowa = glowa->next;
    }

    cout << "Nie ma takiej liczby\n";
}

// Usuwanie podanej liczby
void usun(Element*& glowa, int liczba) {

    Element* temp = glowa;
    Element* poprzedni = NULL;

    // Szukamy liczby
    while (temp != NULL) {

        if (temp->liczba == liczba) {

            // Usuwanie pierwszego elementu
            if (poprzedni == NULL) {
                glowa = temp->next;
            }
            else {
                // Pomijamy usuwany element
                poprzedni->next = temp->next;
            }

            delete temp; // Zwalniamy pamiec

            cout << "Usunieto element\n";
            return;
        }

        // Przechodzimy do nastepnego elementu
        poprzedni = temp;
        temp = temp->next;
    }

    cout << "Nie ma takiego elementu\n";
}

// Odwracanie listy
void odwroc(Element*& glowa) {

    Element* poprzedni = NULL;
    Element* aktualny = glowa;
    Element* nastepny;

    // Zmieniamy kierunek wskaznikow
    while (aktualny != NULL) {

        nastepny = aktualny->next; // Zapamietujemy nastepny

        aktualny->next = poprzedni; // Odwracamy wskaznik

        poprzedni = aktualny;
        aktualny = nastepny;
    }

    glowa = poprzedni; // Ustawiamy nowy poczatek
}

// Usuwanie calej listy
void zwolnij(Element*& glowa) {

    while (glowa != NULL) {

        Element* temp = glowa;

        glowa = glowa->next; // Przechodzimy dalej

        delete temp; // Usuwamy element
    }
}

// Glowna funkcja programu
int main() {

    Element* glowa = NULL; // Pusta lista

    wczytaj(glowa); // Wczytujemy liczby

    cout << "Lista: ";
    wyswietl(glowa);

    int liczba;

    // Podajemy liczbe do wyszukania
    cout << "Podaj liczbe do wyszukania: ";
    cin >> liczba;

    szukaj(glowa, liczba);

    // Podajemy liczbe do usuniecia
    cout << "Podaj liczbe do usuniecia: ";
    cin >> liczba;

    usun(glowa, liczba);

    cout << "Lista po usunieciu: ";
    wyswietl(glowa);

    // Odwracamy kolejnosc elementow
    odwroc(glowa);

    cout << "Lista po odwroceniu: ";
    wyswietl(glowa);

    // Zwalniamy pamiec
    zwolnij(glowa);

    return 0;
}
