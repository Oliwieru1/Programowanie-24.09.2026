﻿
using System.Windows;
using System.Windows.Media;

namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        int count = 0;

        public MainWindow()
        {
            InitializeComponent();
            UpdateCounter();
        }

        private void Increment_Click(object sender, RoutedEventArgs e)
        {
            count++;
            UpdateCounter();
        }

        private void Decrement_Click(object sender, RoutedEventArgs e)
        {
            count--;
            UpdateCounter();
        }

        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            count = 0;
            UpdateCounter();
        }

        private void UpdateCounter()
        {
            CounterBlock.Text = count.ToString();

            if (count > 0)
            {
                CounterBlock.Foreground = Brushes.Green;
            }
            else if (count < 0)
            {
                CounterBlock.Foreground = Brushes.Red;
            }
            else
            {
                CounterBlock.Foreground = Brushes.Black;
            }

            if (count >= 10)
            {
                MessageBlock.Text = "Brawo! Osiągnięto 10 lub więcej!";
            }
            else
            {
                MessageBlock.Text = "";
            }
        }
    }
}
