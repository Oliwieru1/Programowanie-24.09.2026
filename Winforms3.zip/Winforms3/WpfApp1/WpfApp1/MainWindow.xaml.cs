﻿
using System.Windows;


namespace WpfApp1
{
    public partial class MainWindow : Window
    {
        int count = 0;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Increment_Click(object sender, RoutedEventArgs e)
        {
            count++;
            CounterBlock.Text = count.ToString();
        }

        private void Decrement_Click(object sender, RoutedEventArgs e)
        {
            count--;
            CounterBlock.Text = count.ToString();
        }

        
     
    }
}
